package framework;
import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME)
public @interface Before {

}


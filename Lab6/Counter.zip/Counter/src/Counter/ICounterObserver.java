package Counter;

public interface ICounterObserver {
	public abstract void update(int counter);
}

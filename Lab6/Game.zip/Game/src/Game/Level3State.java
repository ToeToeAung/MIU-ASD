package Game;

public class Level3State implements LevelState {

	private int points = 0;
	private Game g;
	
	public Level3State(Game g) {
		this.g = g;
	}
	
	@Override
	public void setPoints(int points) {
		this.points += points;
	}

	@Override
	public void play() {
		System.out.println("Total points = " + points + " --- level = 3");
	}
}

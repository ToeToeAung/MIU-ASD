package Game;

public interface LevelState {
	
	void setPoints(int points);
	
	void play();
}

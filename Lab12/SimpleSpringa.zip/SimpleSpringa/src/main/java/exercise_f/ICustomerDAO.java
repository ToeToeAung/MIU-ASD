package exercise_f;

public interface ICustomerDAO {
	void save(Customer customer);
}

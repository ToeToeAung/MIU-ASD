package exercise_f;

public interface ILogger {
	void update(String msg);
}

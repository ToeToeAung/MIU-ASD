package exercise_f;

public interface IEmailSender {
	void sendEmail();
}

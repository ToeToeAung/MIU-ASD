package exercise_e;

public interface IEmailSender {
	void sendEmail();
}

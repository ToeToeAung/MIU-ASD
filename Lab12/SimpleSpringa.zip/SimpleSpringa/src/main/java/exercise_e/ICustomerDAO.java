package exercise_e;

public interface ICustomerDAO {
	void save(Customer customer);
}

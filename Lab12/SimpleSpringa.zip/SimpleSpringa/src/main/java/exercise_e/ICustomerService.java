package exercise_e;

public interface ICustomerService {
	void addCustomer(String name, String email, String address, String city, int zip);
}

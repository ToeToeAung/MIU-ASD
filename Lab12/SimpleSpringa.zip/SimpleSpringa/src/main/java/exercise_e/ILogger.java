package exercise_e;

public interface ILogger {
	void update(String msg);
}

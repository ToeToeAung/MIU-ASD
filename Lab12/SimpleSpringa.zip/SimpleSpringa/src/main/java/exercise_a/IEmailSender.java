package exercise_a;

public interface IEmailSender {
	void sendEmail();
}

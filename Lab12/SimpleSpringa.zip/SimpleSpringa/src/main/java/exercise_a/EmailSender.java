package exercise_a;

public class EmailSender implements IEmailSender {

	@Override
	public void sendEmail() {
		System.out.println("sending email");
	}
}

package exercise_a;

public interface ILogger {
	void update(String msg);
}

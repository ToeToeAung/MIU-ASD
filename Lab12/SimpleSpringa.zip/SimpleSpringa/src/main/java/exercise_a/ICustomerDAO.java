package exercise_a;

public interface ICustomerDAO {
	void save(Customer customer);
}

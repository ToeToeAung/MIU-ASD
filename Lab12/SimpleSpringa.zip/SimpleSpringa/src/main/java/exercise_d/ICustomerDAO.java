package exercise_d;

public interface ICustomerDAO {
	void save(Customer customer);
}

package exercise_d;

public interface ICustomerService {
	void addCustomer(String name, String email, String address, String city, int zip);
}

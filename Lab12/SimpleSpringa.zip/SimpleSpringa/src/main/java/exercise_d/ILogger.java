package exercise_d;


public interface ILogger {
	void update(String msg);
}

package exercise_d;

public interface IEmailSender {
	void sendEmail();
}

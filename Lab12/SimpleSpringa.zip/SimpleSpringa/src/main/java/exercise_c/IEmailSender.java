package exercise_c;

public interface IEmailSender {
	void sendEmail();
}

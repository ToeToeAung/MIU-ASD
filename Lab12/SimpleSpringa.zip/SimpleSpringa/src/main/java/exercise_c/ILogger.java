package exercise_c;

public interface ILogger {
	void update(String msg);
}

package exercise_b;

public interface IEmailSender {
	void sendEmail();
}

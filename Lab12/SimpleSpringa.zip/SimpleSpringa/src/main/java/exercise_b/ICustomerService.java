package exercise_b;

public interface ICustomerService {
	void addCustomer(String name, String email, String address, String city, int zip);
}

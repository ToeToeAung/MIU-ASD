package exercise_b;

public interface ICustomerDAO {
	void save(Customer customer);
}

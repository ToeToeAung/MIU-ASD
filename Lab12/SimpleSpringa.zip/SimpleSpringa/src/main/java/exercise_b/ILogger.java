package exercise_b;

public interface ILogger {
	void update(String msg);
}

package bank.domain;

public interface IInterestStrategy {
	double calculateInterest(double balance);
}

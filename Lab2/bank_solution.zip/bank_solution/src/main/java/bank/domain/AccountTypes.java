package bank.domain;

public enum AccountTypes {
	CHECKINGS, SAVINGS
}

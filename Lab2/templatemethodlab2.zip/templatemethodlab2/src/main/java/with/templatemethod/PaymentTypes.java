package with.templatemethod;

public enum PaymentTypes {
    VISA, PAYPAL
}

package with.templatemethod;

public enum CurrencyTypes {
    AUD, CAD, EUR, HKD, INR, JPY, SGD, USD
}

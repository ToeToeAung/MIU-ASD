package with.templatemethod;

public interface ICurrencyConverter {
    double convert(double amount);
}

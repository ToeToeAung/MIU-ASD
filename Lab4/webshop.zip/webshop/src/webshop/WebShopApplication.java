package webshop;

public class WebShopApplication {

	public static void main(String[] args) {
		Category shop = new Category("Shop");
		Category book = new Category("Book");
		Category grocery = new Category("Grocery");
        
        Category milk = new Category("Milk Products");
        Category vege = new Category("Vegetables Products");
        
			
		Product lord = new Product("Lord of the Rings");
		lord.setPrice(49.99);
		
		Product cream = new Product("Whipping cream");
		cream.setPrice(4.59);
		
		Product cabbage = new Product("Fresh Green Cabbage");
		cabbage.setPrice(3.32);
		
		shop.addProductComponent(book);		
	    shop.addProductComponent(grocery);
		
	    book.addProductComponent(lord);
				
	    grocery.addProductComponent(milk);
	    grocery.addProductComponent(vege);
		
		milk.addProductComponent(cream);
		vege.addProductComponent(cabbage);
		
		shop.print();


	}

}

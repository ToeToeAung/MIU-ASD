package webshop;

public interface ProductCatalogComponent {

	public abstract void print();

}

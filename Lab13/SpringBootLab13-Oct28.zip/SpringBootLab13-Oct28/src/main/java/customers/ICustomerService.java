package customers;

public interface ICustomerService {
	void addCustomer(Customer customer);
}

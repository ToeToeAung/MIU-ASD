package adapter;

public interface ConverterAdapter {
void setFromType(String fromType);
	
	void setValue(int value);

	void convert();
}

package bank.proxy;

public class Logger {
	public void log(String msg) {
		System.out.println("Logger: " + msg);
	}
}


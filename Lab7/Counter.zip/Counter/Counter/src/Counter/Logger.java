package Counter;

public class Logger {
	public static void writeLog(String msg) {
		System.out.println("Logger: " + msg);
	}
}

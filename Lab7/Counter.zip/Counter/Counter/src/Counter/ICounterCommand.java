package Counter;

public interface ICounterCommand {
	void execute();
}

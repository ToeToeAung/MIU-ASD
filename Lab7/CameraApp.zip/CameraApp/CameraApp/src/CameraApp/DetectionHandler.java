package CameraApp;

public abstract class DetectionHandler {
	CameraRecord record;

	public DetectionHandler(CameraRecord record) {
		this.record = record;
	}

	abstract void detect();
}

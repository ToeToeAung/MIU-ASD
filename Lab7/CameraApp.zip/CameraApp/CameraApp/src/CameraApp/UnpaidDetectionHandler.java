package CameraApp;

import java.util.Arrays;

public class UnpaidDetectionHandler extends DetectionHandler {

	String[] unpaid = { "XYZ0987", "XZY5678" };

	public UnpaidDetectionHandler(CameraRecord record) {
		super(record);
	}

	@Override
	void detect() {
		if (Arrays.asList(unpaid).contains(this.record.licensePlate)) {
			System.out.println("Unpaid ticket whose owner detected!");
		} else {
			DetectionHandler nextHandle = new StolenDetectionHandler(this.record);
			nextHandle.detect();
		}
	}
}

package counter;

public interface Observer {
	public abstract void update(int counter);
}

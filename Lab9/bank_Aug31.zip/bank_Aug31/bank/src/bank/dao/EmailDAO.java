package bank.dao;

public interface EmailDAO {
	void sendEmail();
}

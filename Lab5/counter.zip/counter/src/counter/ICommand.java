package counter;

public interface ICommand {
	void execute();
}

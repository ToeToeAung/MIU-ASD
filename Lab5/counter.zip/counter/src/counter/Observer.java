package counter;

interface Observer {
	public abstract void update(int counter);
}
